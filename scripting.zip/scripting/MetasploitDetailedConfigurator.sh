#!/bin/sh
cd res
sudo ./metasploit-latest-linux-x64-installer.run
cd ..
exit
/bin/sh