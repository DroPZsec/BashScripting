#!/bin/bash
#
#
#

# STARTING

clear
echo "Loading." 
    sleep 1.0
    clear
echo "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5

# TARGET SELECTION

figlet -f big "NMAP-SCANS"
echo 
echo "Enter the IP-address:" 
    read ip;
clear
echo "Target IP:"
echo "$ip"
    sleep 1.0
echo "1.) Standart Server/Service Scan" 
    sleep 0.5
echo "2.) OS-Detection + Traceroute" 
    sleep 0.5
echo "3.) Metasploit-Info Scan" 
    sleep 0.5
echo "4.) Vuln Scan" 
    sleep 0.5
echo "5.) NSE-Vulners Scan"
    sleep 0.5
echo "6.) NSE-Vulscan" 
    sleep 0.5
echo "7.) NSE-X11 Server Scan"
    sleep 0.5
echo "8.) NSE-WhoIs Scan" 
    sleep 0.5
echo "9.) HTTP-auth Scan" 
    sleep 0.5
echo "10.) HTTP-vhosts Scan" 
    sleep 0.5
echo "11.) EXIT" 
    sleep 0.5
echo "Enter your choice:" 
    read attack;
if [ $attack = 1 ]; then
    sudo nmap -Pn -sV $ip
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 2 ]: then
    sudo nmap -Pn -sV -A $ip -v
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 3 ]; then
    sudo nmap -Pn -sV $ip --script metasploit-info --script-args username=root,password=root
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 4 ]; then
    sudo nmap -Pn -sV $ip --script vuln
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi 
if [ $attack = 5 ]; then
    sudo nmap -Pn -sV $ip --script vulners
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 6 ]; then
    sudo nmap -Pn -sV $ip --sctipt vulscan
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 7 ]; then
    sudo nmap -Pn -sV $ip --script x11-access.nse
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 8 ]; then
    sudo nmap -Pn -sV $ip --script whois-domain.nse
    sudo nmap -Pn -sV $ip --script whois-ip.nse
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 9 ]; then
   sudo nmap -Pn -sV -p80 $ip --script http-auth
   echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 10 ]; then
   sudo nmap -Pn -sV -p 80,443,8080 $ip --script http-vhosts 
   echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 11 ]; then
    cd .. && ./BashScripting.sh
    echo
    echo
    echo
    echo "Press 'ENTER' to continue..."
        read
fi
clear
./menu1.sh
/bin/sh