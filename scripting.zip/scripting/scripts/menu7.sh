#!/bin/bash
#
#
#

# STARTING

clear
echo "Loading."
    sleep 1.0
    clear
echo "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5
echo 
figlet -f big "Windows Menu"
echo "1.) SMB-Service Enum"
    sleep 0.5
echo "2.) Check of target metasploit-service is running"
    sleep 0.5 
echo "3.) FTP-NMAP Scan"
    sleep 0.5
echo "4.) NMAP-FTP-Backdoor"
    sleep 0.5
echo "5.) NMAP SQL-Injection"
    sleep 0.5
echo "6.) NMAP Firewall-bypass"
    sleep 0.5
echo "7.) TOR Node NSE Scan"
    sleep 0.5
echo "8.) Check & detect spoofing-source"
    sleep 0.5
echo "9.) Cache system architecture information (memcache-info) Scan"
    sleep 0.5
echo "10.) EXIT"
    sleep 0.5
echo "Enter youre option:"
    read wm;
if [ $wm = 1 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -p 445 $ip --script=smb-ls --script-args 'share=c$,path=\temp'
    sudo nmap -p 445 $ip --script=smb-enum-shares,smb-ls
    sudo nmap -p 445 $ip --script=smb2-security-mode
    sudo nmap -p 139 $ip --script=smb2-security-mode
    nmap --script=smb-system-info.nse -p445 $ip
    sudo nmap -sU -sS --script=smb-system-info.nse -p U:137,T:139 $ip
    sudo nmap --script=smb-enum-services.nse -p445 $ip
    nmap --script=smb-server-stats.nse -p445 $ip
    sudo nmap -sU -sS --script=smb-server-stats.nse -p U:137,T:139 $ip
    echo "SMB Scan finsihed!"
    echo "Press ENTER to continue..."
        read
fi
if [ $wm = 2 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV $ip --script=metasploit-info 
    echo "Target Metasploit-Service scan finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 3 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV $ip --script=ftp-anon.nse
    sudo nmap -Pn -sV $ip --script=ftp-syst.nse
    echo "Target FTP-scan finished!"
    echo "Press'ENTER' to continue..."
        read
fi
if [ $wm = 4 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV --script=ftp-proftpd-backdoor -p 21 $ip
    echo "Target NMAP-Backdoor (scan) finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 5 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV $ip --script=http-sql-injection.nse
    echo "NMAP SQL-Injection (scan) finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 6 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV $ip --script=firewall-bypass.nse --script-args firewall-bypass.helper="ftp", firewall-bypass.targetport=22 
    echo "Firewall-Bypass NSE (scan) finsihed!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 7 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV $ip --script=tor-consensus-checker.nse
    echo "TOR consesus Scan finsihed!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 8 ]; then
    echo "Enter target IP:" 
        read ip;
    sudo nmap -Pn -sV $ip --script=auth-spoof.nse
    echo "Spoof detect finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 9 ]; then
    echo "Enter target IP:"
        read ip;
    sudo nmap -Pn -sV -p11211 $ip --script=memcached-info.nse
    sudo nmap -Pn -sU -p11211 $ip --script=memcached-info.nse
    echo "Memcached-info Scan finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $wm = 10 ]; then
    cd ..
    ./BashScripting.sh
fi
clear
./menu7.sh
/bin/sh