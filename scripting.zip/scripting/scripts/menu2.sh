#!/bin/bash
#
#
#

# STARTING

clear
echo "Loading."
    sleep 1.0
    clear
echo "Loading.."
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5
figlet -f big "ANONSURF MENU" 
sleep 1.0
echo 
echo "1.) Start Anonsurf" 
    sleep 0.5
echo "2.) Stop Anonsurf" 
    sleep 0.5
echo "3.) Anonsurf Status" 
    sleep 0.5
echo "4.) Apache Server Start" 
    sleep 0.5
echo "5.) Apache Server Status" 
    sleep 0.5
echo "6.) Apache Server Stop" 
    sleep 0.5
echo "7.) NGINX Server Start" 
    sleep 0.5
echo "8.) NGINX Server Status" 
    sleep 0.5
echo "9.) NGINX Server Stop" 
    sleep 0.5
echo "10.) MacChanger random MAC"
    sleep 0.5
echo "11.) BackToMainMenu"
    sleep 0.5
echo "Enter your choice:" 
    read action;
if [ $action = 1 ]; then
    sudo anonsurf start
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 2 ]; then
    sudo anonsurf stop
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 3 ]; then 
    sudo anonsurf status
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 4 ]; then
    sudo service apache start
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 5 ]; then
    sudo service apache status
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 6 ]; then
    sudo service nginx stop
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 7 ]; then
    sudo service nginx start
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 8 ]; then
    sudo service nginx status
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 9 ]; then
    sudo service nginx stop
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 10 ]; then 
    echo "Enter target MAC-Address to change:"
        read mac;
    sudo macchanger -r $mac
    echo "your MAC is now changed! You're pretty better anonymized now!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $action = 11 ]; then
    cd ..
    ./BashScripting.sh  
fi 
clear
./menu2.sh
/bin/sh