#!/bin/bash
#
#
#

# STARTING

clear
echo "Loading."
    sleep 1.0
    clear
echo "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...." 
    sleep 1.0
clear
    sleep 0.5
echo 
figlet -f big "WEB-HACKING" 
sleep 1.0
echo
echo "1.)DNSRecon" 
    sleep 0.5
echo "2.)DNSEnum"
    sleep 0.5
echo "3.)CMSeeK" 
    sleep 0.5
echo "4.) RED_HAWK" 
    sleep 0.5
echo "5.) RECON-NG" 
    sleep 0.5
echo "6.) Nikto" 
    sleep 0.5
echo "7.) Websploit" 
    sleep 0.5
echo "8.) BruteX" 
    sleep 0.5
echo "9.) Sn1per" 
    sleep 0.5
echo "10.) WPScan (WordPressScan)"
    sleep 1.0
echo "11.) Exit" 
    sleep 0.5
echo "Enter your choice:" 
    read ans;
if [ $ans = 1 ]; then
    echo "Enter target Website (example.com, without 'www'):" 
        read website;
    dnsrecon -d $website
    echo "DNSRECON finsihed" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $ans = 2 ]; then
    echo "Enter target Website (example.com, without 'www'):" 
        read website;
    dnsenum $website
    echo "DNSenum finished" 
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $ans = 3 ]; then
    echo "starting CMSeeK."
        sleep 0.5
    echo "starting CMSeeK.." 
        sleep 0.5
    echo "starting CMSeeK..." 
        sleep 0.5
    cd ..
    cd res 
    cd CMSeeK
    pytho3 cmseek.py
    echo "CMSeeK Endet"
    cd ..
    cd ..
    cd scripts
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $ans = 4 ]; then
    echo "starting RED_HAWK." 
        sleep 0.5
    echo "starting RED_HAWK.." 
        sleep 0.5
    echo "starting RED_HAWK..." 
        sleep 0.5
    cd ..
    cd res 
    cd RED_HAWK
    php rhawk.php
    echo "RED_HAWK finished"
    echo "Press 'ENTER' to continue..."
        read
    cd ..
    cd ..
    cd scripts
fi
if [ $ans = 5 ]; then
    echo "starting recon-ng." 
        sleep 0.5
    echo "starting recon-ng.." 
        sleep 0.5
    echo "starting recon-ng... " 
        sleep 0.5
    cd ..
    cd res 
    cd recong-ng
    ./recon-ng
    echo "finished with recon-ng" 
    echo "Press 'ENTER' to continue..."
        read
    cd ..
    cd ..
    cd scripts
fi
if [ $ans = 6 ]; then
    echo "GetIntoNikto..." 
        sleep 1.0
    cd ..
    cd res
    cd nikto/program 
    echo "Enter the target (http://www.example.com):" 
        read target;
    perl nikto.pl -h $target 
    echo "nikto finished" 
    echo "Press 'ENTER' to continue..."
        read
    cd ..
    cd ..
    cd ..
    cd scripts
fi
if [ $ans = 7 ]; then
    echo "GoTo Websploit"
        sleep 0.5
    sudo websploit
    echo "Websploit attack finished" 
    echo "Press 'ENTER' to continue..."
        read 
fi
if [ $ans = 8 ]; then
    echo "Enter target IP:" 
        read ip;
    echo "Enter target Port ('Enter for all ports):"
        read port;
    sudo brutex $ip 
    echo "BruteX-Bruteforce finished"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $ans = 9 ]; then 
    echo "Enter target IP:"
        read ip;
    sudo sn1per -t $ip -o -re -b
    echo "Press 'ENTER' to continue..."
    echo "Sn1per-Framework Endet"
        read
fi
if [ $ans = 10 ]; then
    echo "Enter target Website(http://www.---.xx | https://www.---.xx):"
        read website;
    sudo wpscan --url $website -v --detection-mode aggressive -e vp, ap, at, dbe 
    sudo wpscan --url $website -v --detection-mode aggressive -e vp, ap, at, dbe --ignore-main-redirect
    echo "WPScan finished!"
    echo "Press 'ENTER' to continue..."
        read
fi
if [ $ans = 11 ]; then
    cd ..
    ./BashScripting.sh
fi
clear
./menu5.sh
/bin/sh