Tools used in BashScripting Ethical-Hacking-Script:

    figlet
    anonsurf
    apache 
    nginx
    nmap + NSA-script scans + manual install vulnereable scan NSE's
    ruby(dev)
    wpscan
    Metasploit-Framework
    MSFVeom (Metasploit-Framework Payload-Creator)
    DNSEnum
    DNSRecon
    nikto
    RED-HAWK
    Infoga
    metagoofil
    CMSeeK
    websploit
    BruteX
    Sn1per
    MacChanger
    Impulse