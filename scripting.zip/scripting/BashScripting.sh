#!/bin/bash
#BashScripting
#CodedBy@DroPZsec
#FollowOnGithubForMore
#


# STARTING

clear
echo "Loading."
    sleep 1.0
    clear
echo "Loading.." 
    sleep 1.0
    clear
echo "Loading..." 
    sleep 1.0
    clear
echo "Loading...."
    sleep 1.0
clear
    sleep 0.5

# MAIN MENU
figlet -f big "MAIN-MENU"
echo
echo
echo  
sleep 0.5
echo "1.) Standard Scans"  
    sleep 0.5
echo "2.) Anonymize x Server Menu" 
    sleep 0.5
echo "3.) MSF Payload-Creator" 
    sleep 0.5
echo "4.) MSF Exploiting" 
    sleep 0.5 
echo "5.) Web-Hacking" 
    sleep 0.5
echo "6.) DDoS Attacks"
    sleep 0.5
echo "7.) X-tra NSE Script scans"
    sleep 0.5
echo "8.) EXIT" 
    sleep 0.5
echo "Enter your choice:"
    read menu;
    
if [ $menu = 1 ]; then
    cd scripts && ./menu1.sh
fi
if [ $menu = 2 ]; then
    cd scripts && ./menu2.sh
fi
if [ $menu = 3 ]; then
    cd scripts && ./menu3.sh
fi
if [ $menu = 4 ]; then
    cd scripts && ./menu4.sh
fi
if [ $menu = 5 ]; then
    cd scripts && ./menu5.sh
fi
if [ $menu = 6 ]; then
    cd scripts && ./menu6.sh
fi
if [ $menu = 7 ]; then
    cd scripts && ./menu7.sh
fi
if [ $menu = 8 ]; then
    figlet -f big "EXIT FROM BashScripting SCRIPT..."
        sleep 2.0
    clear
    figlet -f small "BYE BYE!"
        sleep 3.0
    exit
fi
exit
/bin/sh