############################
#BashScripting Shell Script#
############################
#
#By DroPZsec
#

LEGAL DISCLAIMER
################
This Tool is coded from ethical-hacker / WhiteHatUsing.
The script thinking to be use as WhiteHat-activities.
All illegal uses are at you're own risks.
To use this Tool legal just scanning youre home-wifi or networks you have owned
Only scan targets with a distance, where you have the dispencies to do this (Bug-Bounty, Pentests...)
################

################
Tools that used in this Script inself are open-source; but the code is  100% selfmade.
Tool-compilation compared to a strong pentest script
Made for private uses
Made for business usecases
Made for (in)official usecases | WhiteHats 
Made for Pentests in all Cases
################

################
In Case of using this Tool always be carefully!
This is a very strong pentest script with many powerfull pentest methods.
Most of techniques aimed to network-security, some for dive-security and most of server-pentesting / server-security
################

################
This tool is scripted to run on Debian(-based) systems like Kali or Parrot.
Tested on: x86_64 GNU/Linux (Debian-CLI)
################


INSTALLING
################
To install all dispencies to release all functions to the script do:
    "chmod +x install.sh"
    "./install.sh"
and that's it!
Than you can start pentesting your target system!

To configure all MSF services and install Metasploit-Framework just type:
    "chmod +x MetasploitDetailedConfigurator.sh"
    "./MetasploitDetailedConfigurator.sh"
And you can use all cases and boxes of Metasploit-Framework!
#################

PAYLOADS
#################
To use the payloads you have created in the script, do:
    "cd selfhosted-MSF-Payloads"
    "ls"
And you can see and use all MSF-Payloads you've ever used!
#################

LEGAL DISCLAIMER 2
#################
All Payloads and Exploits you're created with this tool are at your own risk, your create your own attacks and NOT pre-registred attack-ways.
The case of you're own use decidet on wich criminal - or - legal level this tool is based.
You can anonymize your attacks and activitys with this tool (IP, DNS, MAC) but it's not safe that nobody can track your pentest-attacks.
To hit safer with this Script, you can install a RAM-Blocker (not pre-installed, because RAM's can be very different).
NEVER hit official services or websites with this tool without his owner rights, it can be dangerous for all and trackable for you.
This tool is not maked for attacking, just to get informations of hard-hacking-szenarios and test your logs and servers, how to track evil and dangerous pentests / attacks
#################