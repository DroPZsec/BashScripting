#!/bin/sh
#
#
#

# COLORS

BLUE='\033[94m'
RED='\033[91m'
GREEN='\033[92m'
ORANGE='\033[93m'
RESET='\e[0m'

# START INSTALL SCRIPT

clear
echo $GREEN "This Script install all dispencies for uaing this tool without bugs."
echo "After running this script, youre space might be used in the size of the new installed tools."
echo "Do you want continue?"$RESET $YELLOW "(Y/N)" 
echo $RESET
    read USERINPUT;

if [ $USERINPUT = n ]; then
    echo $GREEN "OK, You're choice!" $RESET
    echo $RED
    echo "bye bye!"
    echo $RESET
    exit
fi

if [ $USERINPUT = y ]; then
    echo "$GREEN allright, starting Installation...$RESET"
    chmod +x *
    sudo apt install -y figlet
        cd scripts
    chmod +x *
        cd ..
    echo $GREEN 
    figlet -f small "Get updates..."
    echo $RESET
        sleep 1.0
    sudo apt --fix-broken install
    sudo apt update && sudo apt upgrade -y
    echo $GREEN "Installing maintaining languages..." $RESET
    sudo apt install -y python3 python python3-pip perl php openssl dnsenum dnsrecon websploit ruby ruby-dev macchanger
    echo $GREEN "Installing Web-Hacking tools..." $RESET
        sleep 1.0
        cd res
    git clone https://github.com/The404Hacking/Infoga
        cd Infoga 
    pip3 install -r requirements.txt
        cd ..
    git clone https://github.com/sullo/nikto
        cd nikto/program
    git checkout nikto-2.5.0
        cd ..
    git clone https://github.com/Tuhinshubhra/RED_HAWK
    git clone https://github.com/LimerBoy/Impulse
    git clone https://github.com/lanmaster53/recon-ng
    git clone https://github.com/sullo/nikto
        cd nikto/program
    git checkout nikto-2.5.0
        cd ..
    git clone https://github.com/Tuhinshubhra/CMSeeK
        cd CMSeeK
    pip3 install -r requirements.txt
    sudo python3 setup.py install
        cd ..
    git clone https://github.com/opsdisk/metagoofil
        cd metagoofil
    pip3 install -r requirements.txt
        cd ..
    cd Impulse
    pip3 install -r requirements.txt
    cd ..
    figlet -f small "Installing Kali-Anonsurf..."
    echo $RESET
        sleep 1.0
    git clone https://github.com/Und3rf10w/kali-anonsurf
        cd kali-anonsurf
    sudo ./installer.sh
        cd ..
    sudo apt --fix-broken install
    echo $GREEN 
    figlet -f small "Installing BruteX, Sn1per & Metasploit-Framework..."
    echo $RESET
        sleep 1.0
    git clone https://github.com/1N3/Sn1per
        cd Sn1per
    sudo ./install.sh
        cd ..
    git clone https://github.com/1N3/Brutex
        cd Brutex
    sudo ./install.sh
        cd ..
    wget https://downloads.metasploit.com/data/releases/metasploit-latest-linux-x64-installer.run
    chmod +x metasploit-latest-linux-x64-installer.run
        cd ..
    echo $GREEN 
    figlet -f small "Installing figlet, apache, nginx, nmap and ruby..."
    echo $RESET
        sleep 1.0
    sudo apt install -y secure-delete i2p socat gufw proxychains openvpn lolcat
    sudo apt install -y nginx nmap ruby
    echo $GREEN 
    figlet -f small "Installing Vulners scripts for NMAP..." 
    echo $RESET
        sleep 1.0
    cd ..
        cd /usr/share/nmap/scripts
    sudo git clone https://github.com/vulnersCom/nmap-vulners.git
    sudo git clone https://github.com/scipag/vulscan.git
    cd
    cd scripting
    echo $GREEN
    figlet -f small "Installing wpscan..."
    echo $RESET
        sleep 1.0
    sudo gem install wpscan
    echo $GREEN
    figlet -f small "DONE!"
    echo $RESET
fi
exit
/bin/sh